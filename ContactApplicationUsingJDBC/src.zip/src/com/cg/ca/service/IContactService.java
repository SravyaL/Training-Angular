package com.cg.ca.service;

import java.util.List;

import com.cg.ca.dto.Contact;
import com.cg.ca.exception.ContactException;

public interface IContactService {
	public boolean add(Contact contact)throws ContactException;
	public boolean remove(int contid)throws ContactException;
	public Contact get(int ContId) throws ContactException;
	public List<Contact> getAll() throws ContactException;
}
